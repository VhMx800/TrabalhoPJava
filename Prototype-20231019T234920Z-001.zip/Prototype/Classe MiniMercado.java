import java.util.HashMap;
import java.util.Map;

public class MiniMercado {
    private Map<String, Produto> registroProdutos = new HashMap<>();

    public void adicionarProduto(String nome, double preco) {
        Produto produto = new Produto(nome, preco);
        registroProdutos.put(nome, produto);
    }

    public Produto clonarProduto(String nome) {
        Produto produto = registroProdutos.get(nome);
        if (produto != null) {
            return produto.clone();
        }
        return null;
    }

    public static void main(String[] args) {
        MiniMercado miniMercado = new MiniMercado();

        miniMercado.adicionarProduto("Arroz", 5.99);
        miniMercado.adicionarProduto("Feijão", 3.99);
        miniMercado.adicionarProduto("Macarrão", 2.49);

        Produto produtoClonado = miniMercado.clonarProduto("Arroz");
        if (produtoClonado != null) {
            produtoClonado.setPreco(6.99);
            System.out.println(produtoClonado);
        }

        Produto produtoNaoRegistrado = miniMercado.clonarProduto("Leite");
        if (produtoNaoRegistrado == null) {
            System.out.println("Produto não encontrado no registro.");
        }
    }
}
