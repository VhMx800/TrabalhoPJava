class hamburguerSimples implements Hamburguer {
  @Override
  public double cost() {
    return 7.00; 
  }
}