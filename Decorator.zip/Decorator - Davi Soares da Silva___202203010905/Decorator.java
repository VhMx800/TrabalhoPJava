abstract class Decorator implements Hamburguer {
  protected Hamburguer hamburguer;

  public Decorator(Hamburguer hamburguer) {
    this.hamburguer = hamburguer;
  }

  @Override
  public double cost() {
    return hamburguer.cost();
  }
}