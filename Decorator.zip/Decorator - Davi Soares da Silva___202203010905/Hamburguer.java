interface Hamburguer{
  double cost();
}