public class Main {
  public static void main(String[] args) {
    Hamburguer hamburguerSimples = new hamburguerSimples();
    System.out.println("Hambúrguer Simples: R$" + hamburguerSimples.cost());

    Hamburguer hamburguerComQueijo = new Queijo(hamburguerSimples);
    System.out.println("Hambúrguer com Queijo: R$" + hamburguerComQueijo.cost());
      
    Hamburguer hamburguerComQueijoEBacon = new Bacon(hamburguerComQueijo);
    System.out.println("Hambúrguer com Queijo e Bacon: R$" + hamburguerComQueijoEBacon.cost());
    }
}