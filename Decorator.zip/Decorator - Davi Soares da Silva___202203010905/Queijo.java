class Queijo extends Decorator{
  public Queijo(Hamburguer hamburguer) {
    super(hamburguer);
  }

  @Override
  public double cost() {
    return super.cost() + 1.50; 
  }
}