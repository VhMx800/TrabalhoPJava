class Bacon extends Decorator{
  public Bacon(Hamburguer hamburguer) {
    super(hamburguer);
  }

  @Override
  public double cost() {
    return super.cost() + 2.00;
  }
}